package preobar.codejam.database;

import android.os.Debug;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import preobar.codejam.entities.User;

/**
 * Created by Fernando on 17/01/2018.
 */

public class FireBaseDataBaseUtils {

    private static List<FirebaseDatabaseUtilListener> listeners;

    public static void addListener(FirebaseDatabaseUtilListener listener) {
        if (listeners == null)
            listeners = new ArrayList<>();
        listeners.add(listener);
    }

    public static void removeListener(FirebaseDatabaseUtilListener listener) {
        if (listeners != null)
            listeners.remove(listener);
    }

    private static FirebaseDatabase m;

    protected static void initialize() {
        if (m == null) {
            m = FirebaseDatabase.getInstance();
            m.setPersistenceEnabled(true);
        }
    }

    public static void insertUser(User user){
        DatabaseReference r = m.getReference("users");
        r.push().setValue(user, new DatabaseReference.CompletionListener() {
            @Override
            public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                for (FirebaseDatabaseUtilListener l: listeners){
                    l.userInseeted();
                }
            }
        });
    }

    public static void getUser(final String username, final String password) {
        initialize();
        m.getReference("users").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot != null && dataSnapshot.getChildrenCount() > 0) {
                    User user = null;
                    Iterator<DataSnapshot> iterator = dataSnapshot.getChildren().iterator();
                    while(iterator.hasNext() && user == null) {
                        User temp = iterator.next().getValue(User.class);
                        if (temp.getPassword() != null && temp.getPassword().equals(password) && temp.getUsername().equals(username)){
                            user = temp;
                        }
                    }

                    for (FirebaseDatabaseUtilListener l: listeners){
                        l.userReturned(user);
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    public interface FirebaseDatabaseUtilListener{
        void userInseeted();
        void userReturned(User user);
    }
}
