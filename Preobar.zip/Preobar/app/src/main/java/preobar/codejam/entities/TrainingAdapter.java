package preobar.codejam.entities;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import preobar.codejam.R;

/**
 * Created by Fernando on 17/01/2018.
 */

public class TrainingAdapter extends RecyclerView.Adapter<TrainingAdapter.TrainingViewHolder> {

    public List<Training> trainings;

    public TrainingAdapter(List<Training> training) {
        this.trainings = training;
    }

    @Override
    public TrainingViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.training_row, parent, false);
        return new TrainingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(TrainingViewHolder holder, int position) {
        Training t = trainings.get(position);
        holder.name.setText(t.getName());
        holder.description.setText(t.getDescription());
    }

    @Override
    public int getItemCount() {
        return trainings.size();
    }

    public class TrainingViewHolder extends  RecyclerView.ViewHolder{

        public TextView name,description;

        public TrainingViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.training_name);
            description = itemView.findViewById(R.id.training_description);
        }


    }
}
