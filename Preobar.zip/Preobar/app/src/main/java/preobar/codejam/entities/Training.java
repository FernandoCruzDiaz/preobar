package preobar.codejam.entities;

/**
 * Created by Fernando on 17/01/2018.
 */

public class Training {
    private String name;
    private String description;
    private float duration;
    private boolean completed;

    public Training(){}
    public Training(String name, String description, float duration, boolean completed) {
        this.name = name;
        this.description = description;
        this.duration = duration;
        this.completed = completed;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getDuration() {
        return duration;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Training training = (Training) o;

        if (Float.compare(training.duration, duration) != 0) return false;
        if (completed != training.completed) return false;
        if (name != null ? !name.equals(training.name) : training.name != null) return false;
        return description != null ? description.equals(training.description) : training.description == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (description != null ? description.hashCode() : 0);
        result = 31 * result + (duration != +0.0f ? Float.floatToIntBits(duration) : 0);
        result = 31 * result + (completed ? 1 : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Training{" +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", duration=" + duration +
                ", completed=" + completed +
                '}';
    }
}
